"use strict"

// userId
pageInit.friends = () => {}
